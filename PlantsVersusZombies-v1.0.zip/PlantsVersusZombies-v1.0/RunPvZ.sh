#!/bin/bash
java -jar PlantsVersusZombies.jar
